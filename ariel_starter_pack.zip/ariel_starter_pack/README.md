# ARIEL Starter Pack
## Automated Reasoning and Interpretable Explanation Layer for LLMs and Hybrid AI

Este pacote foi criado como ponto de partida para uma pesquisa aplicada sobre **Automated Reasoning (AR)** com **LLMs**, **Machine Learning** e sistemas híbridos.

## Conteúdo
- `plano_pesquisa_ARIEL.docx`: documento-base da pesquisa
- `01_ml_explainability_demo.py`: demonstra explicabilidade local para um modelo de ML
- `02_policy_reasoning_demo.py`: demonstra raciocínio híbrido (extração de fatos + regras simbólicas)
- `requirements.txt`: dependências mínimas
- `sample_outputs/`: saídas geradas pelos scripts

## Objetivo técnico
O foco da pesquisa é responder três perguntas:
1. Como explicar decisões de modelos estatísticos de forma auditável?
2. Como combinar LLMs com regras, restrições e verificações formais?
3. Como medir se o “raciocínio” é apenas plausível ou realmente verificável?

## Como executar
```bash
python -m venv .venv
# Linux/macOS
source .venv/bin/activate
# Windows
# .venv\Scripts\activate

pip install -r requirements.txt

python 01_ml_explainability_demo.py
python 02_policy_reasoning_demo.py
```

## Ideia central da pesquisa
Em vez de depender apenas de um LLM gerando texto, o sistema deve produzir:
- resposta
- evidências
- regras aplicadas
- justificativa verificável
- grau de confiança
- trilha de auditoria

## Próximos incrementos recomendados
- adicionar verificador formal (Z3, PyDatalog, Prolog ou Lean)
- incluir avaliação por consistência lógica
- integrar RAG com PostgreSQL + pgvector
- adicionar memória curta em Redis
- versionar políticas e regras
- salvar rastros de decisão em JSON

## Nome sugerido da pesquisa
**ARIEL**
**A**utomated **R**easoning and **I**nterpretable **E**xplanation **L**ayer

Versão em português:
**Camada de Raciocínio Automatizado e Explicação Interpretável para LLMs e IA Híbrida**
